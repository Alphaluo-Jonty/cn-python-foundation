"""
下面的文件将会从csv文件中读取读取短信与电话记录，
你将在以后的课程中了解更多有关读取文件的知识。
"""
import csv
total_numbers = []
with open('texts.csv', 'r') as f:
    reader = csv.reader(f)
    texts = list(reader)
    for index in range(len(texts)):
        curtext = texts[index]
        if len(curtext) >= 2:
            total_numbers.append(curtext[0])
            total_numbers.append(curtext[1])

with open('calls.csv', 'r') as f:
    reader = csv.reader(f)
    calls = list(reader)
    for index in range(len(calls)):
        curcall = calls[index]
        if len(curcall) >= 2:
            total_numbers.append(curcall[0])
            total_numbers.append(curcall[1])

counts = []
for i in range(len(total_numbers)):
    if total_numbers[i] not in counts:
        counts.append(total_numbers[i])

print("There are <{}> different telephone numbers in the records.".format(len(counts)))
"""
任务1：
短信和通话记录中一共有多少电话号码？每个号码只统计一次。
输出信息：
"There are <count> different telephone numbers in the records."
"""
